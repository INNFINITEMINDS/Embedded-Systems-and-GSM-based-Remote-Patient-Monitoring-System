#include <LPC21xx.H>
#include<header.h>
void Uart0_Init()
{
PINSEL0=0X000000005;	
	U0LCR=0X83;			 
	U0DLL=0X61;
	U0DLM=0X00;
	U0LCR=0X03;
}
void Uart1_Init()
{
PINSEL0|=0X00050000;		 // SELECTING PIN0 IN TO UART MODE
	U1LCR=0X83;				   	 // 8=DLAB HIGH ND  3=SELECTING 8 BIT MODE 
	U1DLL=0X61;				   	//SETTING BAUD RATE LSB
	U1DLM=0X00;				    //SETTING BAUD RATE MSB
	U1LCR=0X03;
}
void uart1_tx(unsigned char dat1)
{

	U1THR=dat1;			     
	while(!(U1LSR & 0X20));
}
/***** initialising uart1 receive  ***************/
unsigned char uart1_rx()			  
{
	unsigned int recvd1;

 	while(!(U1LSR & 0X01));
		recvd1=U1RBR;

		return recvd1;
}

/***** uart 0 initializing 	**********/

void uart_transmit(unsigned char rec)
{
   U0THR=rec;
while(!(U0LSR&0X20));
}
 
unsigned char uart_receive()
{
unsigned char a;

while(!(U0LSR&0X01));
		a=U0RBR;
		return(a);
}
void uart_tx_string(unsigned char *Ptr)
{
while(*Ptr)
{
uart_transmit(*Ptr);
Ptr++;
}
}