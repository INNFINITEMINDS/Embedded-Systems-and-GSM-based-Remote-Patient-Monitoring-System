 #include<lpc21xx.h>
 #include<header.h>
//#include<type.h> 

int adc()
{
unsigned int a;
PINSEL1=0x15400000;
ADCR=0x01200004;
a=ADDR; 
while(!(ADDR&0x80000000));
return(a);
}


unsigned int convert(unsigned int dat)
  {

  unsigned int x,y=0,z=1;

   x=dat;
    y=dat>>6;
   y=y & 0x000003ff;
   
   
   while(y!=z)
   {
   dat=adc();
   y=dat>>6;
   y=y & 0x000003ff;
    
   while(y!=z)
   {

   hextobcd(y);
   z=y;
   }
      
   }
   return (y);
  }
    void hextobcd(unsigned int hex)
  {
   unsigned int msb1=0,msb0=0,lsb1=0,lsb0=0;
   
  while(hex>=100)
  {
  hex=hex-100;
  msb0++;
  }
 while(hex>=10)
  {
  hex=hex-10;
  lsb1++;
  }
  lsb0=hex;
 
 msb0=msb0+0x30;
  msb1=msb1+0x30;
  lsb0=lsb0+0x30;
  lsb1=lsb1+0x30;
 
  lcdString("Temperature:"); 
  datawrt(msb1);
  datawrt(msb0);
  datawrt(lsb1);
  datawrt(lsb0);	
   }
