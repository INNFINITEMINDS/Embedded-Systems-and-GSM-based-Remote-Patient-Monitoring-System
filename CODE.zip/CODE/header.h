int adc();
unsigned int convert(unsigned int dat);
void hextobcd(unsigned int hex);
 void delay2();
void lcdint();
void cmdwrt(unsigned int command);
void datawrt(unsigned int data);
void lcdString( unsigned char *ptr );
void sec_delay(unsigned int delay_count);
void delay();
void hr();

//gsm//
void Gsm_Init();
void Gsm_Del_Msg();
void Gsm_read();
//uart//
void Uart0_Init();
void Uart1_Init();
void uart1_tx(unsigned char );
unsigned char uart1_rx();
void uart_transmit(unsigned char );
unsigned char uart_receive();
void uart_tx_string(unsigned char *);
