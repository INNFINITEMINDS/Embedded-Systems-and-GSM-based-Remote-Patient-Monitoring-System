#include<header.h>
#include<lpc21xx.h>

void lcdint()
{
 unsigned int c[6]={0x02,0x28,0x0E,0x01,0x06,0x80};
 unsigned char i;
 for(i=0;i<7;i++)
   {
      cmdwrt(c[i]);
   }
}

void cmdwrt(unsigned int command)
{
  unsigned int x;
  x=command;
  x=x & 0xf0;
  x=x<<6;
  IOCLR0 = 0x00003c00;
  IOSET0=x;
  IOCLR1=0x03000000;			//register select and enable
  IOSET1=0x02000000;
  delay();
  IOCLR1=0x02000000;
  delay();
  x=command;
  x=x & 0x0f;
  IOCLR0 = 0x00003c00;
  x=x<<10;
  IOSET0=x;
  IOCLR1=0x03000000;			//register select and enable
  IOSET1=0x02000000;
  delay();
  IOCLR1=0x02000000;
  delay();
  }
  
 void datawrt(unsigned int data)
{
  unsigned int value;
  value=data;
  value=value & 0xf0;
  value=value<<6;
  IOCLR0 = 0x00003c00;
  IOSET0=value;
  IOCLR1=0x03000000;
  IOSET1=0x03000000;
  delay();
  IOCLR1=0x02000000;
  delay();
  value=data;
  value=value & 0x0f;
  IOCLR0 = 0x00003c00;
  value=value<<10;
  IOSET0=value;
  IOCLR1=0x03000000;
  IOSET1=0x03000000;
 delay();
  IOCLR1=0x02000000;
  delay();
  }

  void lcdString( unsigned char *ptr )
  {
 	while( *ptr != '\0')
	datawrt( *ptr++ );
  }
void delay()
{
  unsigned int i;
  for(i=0;i<=60000;i++);

}	 