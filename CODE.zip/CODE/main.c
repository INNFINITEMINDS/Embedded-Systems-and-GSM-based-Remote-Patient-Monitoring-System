#include<LPC21XX.H>
#include<header.h>

unsigned char str[6];
extern unsigned char i;
extern unsigned char pno[19];
unsigned char cmd_7[]="AT+CPMS?";
unsigned char cmd_5[]="AT+CMGS=\"9663477872\"";
//unsigned char cmd_10[]="ATD+919663477872;";	
 unsigned int count=0,p;
  unsigned char disp_hb_flg =0;
	unsigned char heart_flg=0;
	unsigned int dat,val,x;



void tc1(void) __irq 
{		
	/*Disable Timer 1*/
	T1TCR=0x00000000;
	/*Rest Timer, Interupt and stop*/
	T1MCR=0x00000007;			
	/*Clear match 0 interrupt*/
	T1IR= 0x00000001; 
	disp_hb_flg = 1;
	VICVectAddr = 0x00000000; //Dummy write to signal end of interrupt
}
//***************************************** external intrrupt1 P0.9
void ext(void) __irq 
{ 
    lcdString("int");
	/*Disable Ext Int 3*/
	EXTINT=0X04;
	/*Start Timer 1*/
	T1TCR=0x00000001;
	/*Count the pulse*/
	count++; 			
	VICVectAddr = 0x00000000; //Dummy write to signal end of interrupt	 

	/*Enable Ext Int 1*/
	VICIntEnable |= 0x00010000;

}
void heart_beat_init()
				{
			PINSEL0|=0X0000c000; 			
			T1PR=15000000;  /*Load prescaler for 1 sec tick	 */
			T1MCR=0x00000007; /*On match reset the counter and generate an interrupt*/
			T1MR0=0x0000000a; /*Set the cycle time*/
			VICVectCntl5= 0x00000025; /*Set channel*/
			VICIntEnable|= 0x00000020; /*Enable the interrupt*/
			VICVectAddr5 =(int)tc1; /*Set the timer ISR vector address	 */
			EXTPOLAR=0x00;  	 	/*ext int config*/
			EXTMODE=0x04;
			VICIntEnable = 0x00010000;	 /*enable EXT2	*/		
			VICVectCntl0 = 0x00000030; 
			VICVectAddr0=(int)ext; /*Set the timer ISR vector address*/

				}


void sec_delay(unsigned int delay_count)
{
	unsigned int delaycount1,delaycount2;
	while(delay_count--)
	{
		delaycount1=100;			
		while(delaycount1--)
		{
			delaycount2=550;
			while(delaycount2--);
		}
	}
}

void delay1(unsigned int it)
{
  unsigned int i;
  for(i=0;i<=it;i++);

}

void main()
{
//unsigned char recv;				  //CHECKING INBOX
   PINSEL0|=0x00000000;
   PINSEL1|=0x00000000;
   IODIR0|=0x00003c00;
   IODIR1|=0x03000000;
   PINSEL0|=0X0040005;
   //initFiq();
   lcdint();
   Uart0_Init();
   Uart1_Init();		   
   delay1(800000);
	 cmdwrt(0x01);
	 cmdwrt(0x80);
	 lcdString ("Designing of Tele");
	  cmdwrt(0xc0);
	 lcdString ("Medicine appl..");
	   sec_delay(500);
	   Gsm_Init();
	     cmdwrt(0x01);
	 cmdwrt(0x80);
	   lcdString ("GSM ENABLED");
	    sec_delay(500);

	  
   while(1)
   {
   cmdwrt(0x01);
	 cmdwrt(0x80);
   lcdString("STATUS......");
   sec_delay(500);	
     heart_beat_init();		 
	  // recv=uart_receive() ;
			  cmdwrt(0xc0);
	   		 lcdString("please wait");
			 lcdString(".");
			 sec_delay(500);
			 lcdString(".");
			 sec_delay(500);
			 lcdString(".");
			 sec_delay(500);
			 lcdString(".");
			 sec_delay(500);
			 lcdString(".");
			 sec_delay(500);		
			 cmdwrt(0x01);
	//	adc();
	dat=adc();
   x=dat;
   val=convert(x);
		sec_delay(500);
			{
			if(val<30)
			{ 
			cmdwrt(0xc0);
			lcdString("  NORMAL   ");
			sec_delay(500);
			}
			else 
			{
			cmdwrt(0xc0);
			lcdString("  ABNORMAL   ");
			sec_delay(500);
				for(i=0;cmd_5[i]!='\0';i++)
						{
						uart_transmit(cmd_5[i]);        // attention command for sending message to phone number
						}
					    uart_transmit(0X0A);
					    uart_transmit(0X0D);
						uart_tx_string("Abnormal Temperature");
						uart_transmit(0X1A);
						sec_delay(100);
						lcdString("calling doctor");
						 cmdwrt(0xc0);
						lcdString("please wait");
			 			lcdString(".");
						 sec_delay(500);
						 lcdString(".");
						 sec_delay(500);
						 lcdString(".");
						 sec_delay(500);
						 lcdString(".");
						 sec_delay(500);
						if(disp_hb_flg == 1)
		   {
		   	/*Disable display flag */
			disp_hb_flg =0;		
			
		//Put the Heart Beat Data to LCD 
		   if(count<72&&count<100)
		   	{ 
			heart_flg=1; 
			cmdwrt(0x01);
			cmdwrt(0x80);
	        lcdString(" ABNORMAL ");
			cmdwrt(0xc0);
			lcdString("  HEART RATE   ");
				for(i=0;cmd_5[i]!='\0';i++)
						{
						uart_transmit(cmd_5[i]);        // attention command for sending message to phone number
						}
					    uart_transmit(0X0A);
					    uart_transmit(0X0D);
						uart_tx_string("Abnormal heart rate");
						uart_transmit(0X1A);
						sec_delay(100);
						lcdString("calling doctor");
						 cmdwrt(0xc0);
						lcdString("please wait");
			 			lcdString(".");
						 sec_delay(500);
						 lcdString(".");
						 sec_delay(500);
						 lcdString(".");
						 sec_delay(500);
						 lcdString(".");
						 sec_delay(500);
		//uart_tx_string("123");
		}
		else
		{
		heart_flg=0;
		  cmdwrt(0x01);
			cmdwrt(0x80);
	        lcdString(" NORMAL ");
			cmdwrt(0xc0);
			lcdString("  HEART RATE   ");
			}
			count=0;
			}
			}
		}  

			
 	 }
}





































