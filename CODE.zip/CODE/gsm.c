#include<lpc21xx.h>
#include<string.h>
#include<header.h>

 unsigned char i;
unsigned char cmd_1[]="AT";			  				//attention command
unsigned char cmd_2[]="ATE0";						//charecters not echoed
unsigned char cmd_3[]="AT+CNMI=2,1,0,0,0";	//procedure for message reception from the n/w 	    
unsigned char cmd_4[]="AT+CMGF=1";					//set text mode
unsigned char cmd_6[]="AT&W";	 					//modification saving in eeprom
unsigned char cmd_9[]="AT+CMGD=1,4";  //DELETE ALL MESSAGES IN INBOX
unsigned char cmd_8[]="AT+CMGR=1";
unsigned char pno[19];
unsigned char cmd_10[]="ATD+919663477872;";	



void Gsm_Init()
{
for(i=0;cmd_1[i]!='\0';i++)
{
uart_transmit(cmd_1[i]);                             // attention command
}
uart_transmit(0X0A);
uart_transmit(0X0D);

//while(uart_receive()!='K');

for(i=0;cmd_6[i]!='\0';i++)
{
uart_transmit(cmd_6[i]);                             // at&w,modification saving in eeprom
}
uart_transmit(0X0A);
uart_transmit(0X0D);
//while(uart_receive()!='K');


for(i=0;cmd_2[i]!='\0';i++)
{
uart_transmit(cmd_2[i]);                             // attention command for echo
}
uart_transmit(0X0A);
uart_transmit(0X0D);
//while(uart_receive()!='K');

for(i=0;cmd_3[i]!='\0';i++)
{
uart_transmit(cmd_3[i]);               //procedure for message reception from the n/w 
}
uart_transmit(0X0A);
uart_transmit(0X0D);
//while(uart_receive()!='K');

for(i=0;cmd_4[i]!='\0';i++)
{
uart_transmit(cmd_4[i]);                 // attention command for message in text mode
}
uart_transmit(0X0A);
uart_transmit(0X0D);		   
//while(uart_receive()!='K');
/*for(i=0;cmd_10[i]!='\0';i++)
{
uart_transmit(cmd_10[i]);                 // attention command for calling
}
uart_transmit(0X0A);
uart_transmit(0X0D);
} */
}

void Gsm_Del_Msg()
{
	for(i=0;cmd_9[i]!='\0';i++)
            {
         uart_transmit(cmd_9[i]);        //	COMMAND to delete all MESSAGES
            }
			uart_transmit(0X0A);
            uart_transmit(0X0D);
			cmdwrt(0x01);
			cmdwrt(0xc0);
			datawrt('*');			  // * shows message deleted
}
 void Gsm_read()						 //"AT+CMGR=1"
{
for(i=0;cmd_8[i]!='\0';i++)			  //"AT+CMGR=1"
            {
           uart_transmit(cmd_8[i]);         //	COMMAND READ THE FIRST MESSAGE
            }
			uart_transmit(0X0A);   //line feed(ctrl j or \n)
            uart_transmit(0X0D);	//carrige return(ctrl m)
		   	while(uart_receive()!=',');
		   	while(uart_receive()!='1');
			for(i=0;i<10;i++)
			{
			pno[i]=uart_receive();		 // getting phone no in pno[i]
			}
}              